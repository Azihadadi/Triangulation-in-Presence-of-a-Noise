clc;
clear all;
close all;

one = ones(1,100);
%% Make a scene
data = load('data.mat');
p3D = data.X;
p3D = [p3D;one];
p3D = round(p3D,4);

%% Define two cameras
left_camera = CentralCamera('default','pose',transl(0,0,-10)*trotz(0)*troty(0));
left_p2D = left_camera.C*p3D;
left_p2D = round(left_p2D./left_p2D(3,:),4);
left_p2D = left_p2D(1:2,:);

right_camera = CentralCamera('default','pose',transl(0.5,0,-10)*trotz(0)*troty(0));
right_p2D = right_camera.C*p3D;
right_p2D = round(right_p2D./right_p2D(3,:),4);
right_p2D = right_p2D(1:2,:);

%% Visualize the cameras and the scene
left_camera.plot_camera;
% right_camera.plot_camera;
plot_sphere(p3D,0.1);
% title('3-D model without noise')

%% Visualize the left and right projected images
figure 
plot_point(left_p2D, 'bo', 'MarkerFaceColor', 'r');
title('projected image by the left camera')

figure
plot_point(right_p2D, 'bo', 'MarkerFaceColor', 'g');
title('projected image by the right camera')

%% Add the Gaussian noise to two images
variance = 5;
mean = 0;
noise = (sqrt(variance)*randn(2,100)) + mean;
left_p2Dn = round(left_p2D + noise,4);
right_p2Dn = round(right_p2D + noise,4);

%% Visualize the left and right projected noisy images
figure 
plot_point(left_p2D, 'bo', 'MarkerFaceColor', 'r');
plot_point(left_p2Dn, 'bx', 'MarkerFaceColor', 'g');
title('projected noisy image by the left camera')
figure
plot_point(right_p2D, 'bo', 'MarkerFaceColor', 'g');
plot_point(right_p2Dn, 'bx', 'MarkerFaceColor', 'g');
title('projected noisy image by the right camera')

%% Triangulation with optimal correction of image projections
pts3D=stereoReconsPts(left_camera.C, right_camera.C, left_p2D, right_p2D,[], 'none');
pts3D = [pts3D;one];
figure
plot_sphere(pts3D,0.1);
title('triangulation of noise free image projections')

pts3D_poly=stereoReconsPts(left_camera.C, right_camera.C, left_p2Dn, right_p2Dn,[], 'none');
pts3D_poly = [pts3D_poly;one];
figure
plot_sphere(pts3D_poly,0.1);
title('triangulation with optimal correction of noisy image projections')

%% Generate Error in presence of a Gaussian noise 
for i=1:100
    variance = i*5;
    mean = 0;
    noise = sqrt(variance)*randn(size(2,100)) + mean;
    left_p2D_n = (left_p2D + noise);
    right_p2D_n = (right_p2D + noise);    
    pts3D=stereoReconsPts(left_camera.C, right_camera.C, left_p2D_n, right_p2D_n,[], 'poly');
    e(i)=abs(sum(sum(pts3D-p3D(1:3,:))));
end
%% Error analysis has been done in error_analysis.m file


