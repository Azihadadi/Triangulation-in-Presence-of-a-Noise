clc
clear all
close all
%% load error
load('error_all.mat')
e0=none_e;
e1=poly_e;
e2=midp_e;
e3=lind_e;
e4=sampson_e;
%% error calcuation for each dataset
ev=[];
for i=1:10:100
    ev=[ev var(e4(i:i+10-1))];
end
figure
bar(ev)
xlabel('cluster points')
ylabel('error amplitude')
%% smooth data error curve
es0=smoothts(none_e,'b',5);
es1=smoothts(poly_e,'b',5);
es2=smoothts(midp_e,'b',5);
es3=smoothts(lind_e,'b',5);
es4=smoothts(sampson_e,'b',5);
%% show method's error analysis curve separately
figure
subplot(3,2,1),plot(es0,'r'),xlabel('number of 3D points'),ylabel('error amplitude')
subplot(3,2,2),plot(es1,'g'),xlabel('number of 3D points'),ylabel('error amplitude')
subplot(3,2,3),plot(es2,'b'),xlabel('number of 3D points'),ylabel('error amplitude')
subplot(3,2,4),plot(es3,'y'),xlabel('number of 3D points'),ylabel('error amplitude')
subplot(3,2,5),plot(es4,'c'),xlabel('number of 3D points'),ylabel('error amplitude')
%% show method's error analysis curve
figure
hold on
plot(es0,'r')
plot(es1,'g')
plot(es2,'b')
plot(es3,'y')
plot(es4,'c')
xlabel('number of 3D points')
ylabel('error amplitude')
hold off
%% show method's error analysis
Error=[sum(e0) sum(e1) sum(e2) sum(e3) sum(e4)];
Error1=[mean(e0) mean(e1) mean(e2) mean(e3) mean(e4)];
Error2=[var(e0) var(e1) var(e2) var(e3) var(e4)];
Error3=[max(e0) max(e1) max(e2) max(e3) max(e4)];
Error4=[min(e0) min(e1) min(e2) min(e3) min(e4)];
figure
subplot(2,2,1),bar(Error1),xlabel('correction methods'), ylabel('mean error')  
subplot(2,2,2),bar(Error2),xlabel('correction methods'), ylabel('variance error')
subplot(2,2,3),bar(Error3),xlabel('correction methods'), ylabel('maximum error')
subplot(2,2,4),bar(Error4),xlabel('correction methods'), ylabel('minimum error')